This folder contains the main results of the analysis in the article. The results from each data chart in the text have been listed separately.
